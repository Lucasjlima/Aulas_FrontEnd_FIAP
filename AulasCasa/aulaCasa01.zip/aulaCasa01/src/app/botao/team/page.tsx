'use client'

import Header from "@/app/Components/Header/Header"

export default function Team() {
    return(
        <div className="min-h-screen flex flex-col">
            <Header title="Team"/>

        </div>
    )
}