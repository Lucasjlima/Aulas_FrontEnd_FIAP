import React from 'react';
import CompFormulario from '../Components/compFormulario/compFormulario';


const Funcionario = () => {
return(
    <>
    <CompFormulario/>
    </>
);

}


export default Funcionario;