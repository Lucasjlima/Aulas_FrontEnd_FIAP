import CompContato from "../Components/compContato/compContato";
const Contato = () => {
    return(
        <>
        <CompContato/>
        </>
    )
}

export default Contato;