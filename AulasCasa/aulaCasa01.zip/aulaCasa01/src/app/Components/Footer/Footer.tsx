const Footer = () =>{
    return(
        <footer className="bg-gray-800 text-white p-4 text-center mt-4">
            <p>&copy; 2025 Meu site. Todos direitos reservados</p>
        </footer>
    )
}

export default Footer;