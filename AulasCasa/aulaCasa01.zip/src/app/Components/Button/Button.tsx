type ButtonProps = {
    text : String;
    onClick : () => void;
    variant?: 'primary' | 'secondary';

};