import CompFooter from './components/compFooter/compFooter';
import CompFormulario from './components/compFormulario/compFormulario';
import CompHeader from './components/compHeader/compHeader';
import compHeader from './components/compHeader/compHeader';


export default function Home() {
  return (
    <>

      <div className='min-h-screen'>
        <main>
          <CompHeader />
          <CompFormulario/>
        </main>


      </div>
      <CompFooter />
    </>
  );
}
