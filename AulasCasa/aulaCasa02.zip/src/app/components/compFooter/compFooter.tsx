const compFooter = () => {
    return (
        <footer className="bg-green-200 text-black p-4 text-center mt-4 font-bold">
            <p>
               &copy; 2025 Formulario. Todos os direitos reservados. 
            </p>

        </footer>

    )
}

export default compFooter;