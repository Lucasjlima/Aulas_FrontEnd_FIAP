'use client'
import { useState } from "react";

export default function compFormulario() {
    const [nome, setNome] = useState("");
    const [rua, setRua] = useState("");
    const [numero, setNumero] = useState("");
    const [cpf, setCpf] = useState("");
    const [dataNasc, setDataNasc] = useState("");


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        console.log({
            nome,
            rua,
            numero,
            cpf,
            dataNasc,
        });
        alert("Formulário enviado com sucesso!");
    };

    return (
        <form onSubmit={handleSubmit} className="max-w-md mx-auto p-4 bg-white  shadow-md rounded">
            <h1 className="text-2xl font-bold mb-4 text-center">Formulário</h1>

            <label className="block mb-2">
                Nome:
                <input
                    type="text"
                    className="w-full border p-2 rounded mt-1"
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                />
            </label>

            <label className="block mb-2">
                Rua:
                <input
                    type="text"
                    className="w-full border p-2 rounded mt-1"
                    value={rua}
                    onChange={(e) => setRua(e.target.value)}
                />
            </label>

            <label className="block mb-2">
                Numero:
                <input
                    type="numero"
                    className="w-full border p-2 rounded mt-1"
                    value={nome}
                    onChange={(e) => setNumero(e.target.value)}
                />
            </label>

            <label className="block mb-2">
                Cpf:
                <input
                    type="text"
                    className="w-full border p-2 rounded mt-1"
                    value={cpf}
                    onChange={(e) => setCpf(e.target.value)}
                />
            </label>

            <label className="block mb-4">
                Data de Nascimento:
                <input
                    type="text"
                    className="w-full border p-2 rounded mt-1"
                    value={dataNasc}
                    onChange={(e) => setDataNasc(e.target.value)}
                />
            </label>

            <button type="submit"
                className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-200">
                    Enviar
            </button>







        </form>
    )
}