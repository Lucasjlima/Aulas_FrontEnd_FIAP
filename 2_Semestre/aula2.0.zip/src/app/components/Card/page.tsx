function Card() {
    return(
        <>
        <h1>Component Card</h1>
        </>
    )
}
export default Card;
 
export function Auxiliar() {
    return(
        <>
            <h2>Criando funcoes auxiliares</h2>
        </>
    )
}