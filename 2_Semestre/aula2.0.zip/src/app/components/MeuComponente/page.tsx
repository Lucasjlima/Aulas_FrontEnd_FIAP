const MeuComponente = () => {
    return (
        <>
            {/* Criando Arrow function */}
            <h1>Meu Componente, criado com Arrow function</h1>
        </>
    )
}

export default MeuComponente;