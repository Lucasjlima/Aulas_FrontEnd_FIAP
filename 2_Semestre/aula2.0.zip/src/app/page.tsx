import Card, { Auxiliar } from "../app/components/Card/page";
import MeuComponente from "./components/MeuComponente/page";
export default function Home() {
  return (
    <>
      <h1>Hello world!!!</h1>
 
      <Card />
 
      <MeuComponente />
 
      <Auxiliar />
    </>
  );
}
 