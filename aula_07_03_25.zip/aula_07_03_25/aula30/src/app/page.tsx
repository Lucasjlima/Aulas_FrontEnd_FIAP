'use client'
import { useState } from "react";

export default function Home() {

  const [valor, setValor] = useState(0)
  const [dados,setDados] = useState('')
  const [nomes,setNomes] = useState('')
  const[conteudo,setConteudo] = useState('')

  const handleChange = (event : React.ChangeEvent<HTMLInputElement>) =>{
    setDados(event.target.value)
  }
  const handleChangev2 = (event : React.ChangeEvent<HTMLInputElement>) =>{
    setNomes(event.target.value)
  }

  const exibirConteudo = () =>{
      setConteudo(nomes);
      setNomes('')
  }
  return (
    <>

      <h1>Trabalhando com useState</h1>
      <h2>Exemplo 1</h2>

      <button onClick={() => {setValor(valor + 1)}}>Incrementar</button>
      <br />
      <button onClick={() => {setValor(valor - 1)}} disabled={ valor == 0 }>Subtrair</button>
      <br />
      <button onClick={() => {setValor(valor - 1)}}>Subtrair negativos</button>
      <br />
      <button onClick={() => {setValor(valor - valor)}}>Voltar para zero</button>
      <br />
      <button onClick={() => {setValor(valor * valor)}}>elevar ao quadrado</button>
      <br />
      <p>Novo valor:{valor} </p>

      <h1>Exemplo 2</h1>
      dados : <input value={ dados } onChange={ handleChange }/>
      <p>Valor digitado: { dados }</p>
      
      <h3>Exemplo 03</h3>
      <form onSubmit={ (e) => {e.preventDefault} }>
      Nome : <input value={ nomes } onChange={ handleChangev2 } />
      <button type="button" onClick={ exibirConteudo }>Enviar</button>
      <p >Nome digitado: { conteudo } </p>
      </form>
      
    </>
  );
}
